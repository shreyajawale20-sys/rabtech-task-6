const $ = (id) => document.getElementById(id);
const state = { view: "dashboard" };
const endpoints = {
  patients: "/api/patients",
  doctors: "/api/doctors",
  appointments: "/api/appointments"
};
$("today").textContent = new Date().toLocaleDateString(undefined, {weekday:"short", month:"short", day:"numeric", year:"numeric"});

function notify(message, error=false) {
  const box=$("notice"); box.textContent=message; box.classList.toggle("error",error); box.classList.remove("hidden");
  window.setTimeout(()=>box.classList.add("hidden"),4500);
}
async function api(url, options={}) {
  const response=await fetch(url,{...options,headers:{"Content-Type":"application/json",...(options.headers||{})}});
  const text=await response.text();
  let data=null; try{data=text?JSON.parse(text):null;}catch{data=text;}
  if(!response.ok) throw new Error(data?.message || data?.error || `Request failed (${response.status})`);
  return data;
}
function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function fillTable(id, rows, columns, emptyMessage) {
  const body=$(id);
  if(!rows.length){body.innerHTML=`<tr><td class="empty" colspan="${columns.length}">${emptyMessage}</td></tr>`;return;}
  body.innerHTML=rows.map(row=>`<tr>${columns.map(col=>`<td>${col.render?col.render(row):escapeHtml(row[col.key])}</td>`).join("")}</tr>`).join("");
}
async function loadDashboard(){
  const s=await api("/api/dashboard/summary");
  $("patientCount").textContent=s.patients;$("doctorCount").textContent=s.doctors;$("appointmentCount").textContent=s.appointments;
}
async function loadPatients(){
  const rows=await api(endpoints.patients);
  fillTable("patientsTable",rows,[
    {key:"id"},{key:"name"},{key:"age"},{key:"gender"},{key:"email"},{key:"phone"}
  ],"No patient records yet. Add your first patient.");
}
async function loadDoctors(){
  const rows=await api(endpoints.doctors);
  fillTable("doctorsTable",rows,[
    {key:"id"},{key:"name"},{key:"specialization"},{key:"email"},{key:"availability"}
  ],"No doctors listed yet. Add a doctor to the directory.");
}
async function loadAppointments(){
  const rows=await api(endpoints.appointments);
  fillTable("appointmentsTable",rows,[
    {key:"id"},{key:"patientName"},{key:"doctorName"},{key:"appointmentDate"},{key:"reason"},
    {key:"status",render:r=>`<span class="status">${escapeHtml(r.status)}</span>`},
    {key:"id",render:r=>`<button class="primary cancel-appointment" data-id="${r.id}" ${r.status==="CANCELLED"?"disabled":""}>Cancel</button>`}
  ],"No appointments booked yet.");
}
async function refresh(){
  try{
    await Promise.all([loadDashboard(),loadPatients(),loadDoctors(),loadAppointments()]);
    $("apiStatus").textContent="Connected";
  }catch(e){$("apiStatus").textContent="Offline";notify(`Backend connection error: ${e.message}. Check that Spring Boot is running.`,true);}
}
async function showView(view){
  state.view=view;
  document.querySelectorAll(".view").forEach(el=>el.classList.add("hidden"));
  $(`${view}View`).classList.remove("hidden");
  document.querySelectorAll(".nav-item").forEach(el=>el.classList.toggle("active",el.dataset.view===view));
  $("pageTitle").textContent=({dashboard:"Dashboard overview",patients:"Patient directory",doctors:"Doctor directory",appointments:"Appointment management"})[view];
  try{if(view==="dashboard")await loadDashboard();if(view==="patients")await loadPatients();if(view==="doctors")await loadDoctors();if(view==="appointments")await loadAppointments();}
  catch(e){notify(e.message,true);}
}
document.querySelectorAll("[data-view]").forEach(el=>el.addEventListener("click",()=>showView(el.dataset.view)));
$("refreshBtn").addEventListener("click",refresh);
$("showPatientForm").addEventListener("click",()=>$("patientForm").classList.toggle("hidden"));
$("showDoctorForm").addEventListener("click",()=>$("doctorForm").classList.toggle("hidden"));
$("showAppointmentForm").addEventListener("click",()=>$("appointmentForm").classList.toggle("hidden"));

async function submitForm(formId, url, after, transform=x=>x){
  $(formId).addEventListener("submit",async e=>{
    e.preventDefault(); const form=e.currentTarget; const values=Object.fromEntries(new FormData(form).entries());
    try{await api(url,{method:"POST",body:JSON.stringify(transform(values))});form.reset();form.classList.add("hidden");notify("Saved successfully.");await after();await loadDashboard();}
    catch(err){notify(err.message,true);}
  });
}
submitForm("patientForm",endpoints.patients,loadPatients,v=>({...v,age:Number(v.age)}));
submitForm("doctorForm",endpoints.doctors,loadDoctors);
submitForm("appointmentForm",endpoints.appointments,loadAppointments);
$("appointmentsTable").addEventListener("click",async e=>{
  const button=e.target.closest(".cancel-appointment");if(!button)return;
  try{await api(`${endpoints.appointments}/${button.dataset.id}/status?status=CANCELLED`,{method:"PATCH"});notify("Appointment cancelled.");await loadAppointments();await loadDashboard();}
  catch(err){notify(err.message,true);}
});
refresh();
