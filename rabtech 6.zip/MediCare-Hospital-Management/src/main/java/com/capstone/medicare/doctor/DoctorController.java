package com.capstone.medicare.doctor;

import com.capstone.medicare.exception.ResourceNotFoundException;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/doctors")
public class DoctorController {
    private final DoctorRepository repository;
    public DoctorController(DoctorRepository repository){this.repository=repository;}

    @GetMapping public List<Doctor> all(){return repository.findAll();}
    @GetMapping("/{id}") public Doctor get(@PathVariable Long id){
        return repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Doctor not found: "+id));
    }
    @PostMapping public Doctor create(@Valid @RequestBody Doctor doctor){doctor.setAvailability("Available");return repository.save(doctor);}
    @PutMapping("/{id}") public Doctor update(@PathVariable Long id,@Valid @RequestBody Doctor input){
        Doctor d=get(id); d.setName(input.getName());d.setSpecialization(input.getSpecialization());d.setEmail(input.getEmail());d.setAvailability(input.getAvailability());return repository.save(d);
    }
    @DeleteMapping("/{id}") public void delete(@PathVariable Long id){repository.delete(get(id));}
}
