package com.capstone.medicare.appointment;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDate;

@Entity
public class Appointment {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotBlank private String patientName;
    @NotBlank private String doctorName;
    @NotNull private LocalDate appointmentDate;
    @NotBlank private String reason;
    private String status = "BOOKED";

    public Appointment(){}
    public Long getId(){return id;}
    public String getPatientName(){return patientName;}
    public String getDoctorName(){return doctorName;}
    public LocalDate getAppointmentDate(){return appointmentDate;}
    public String getReason(){return reason;}
    public String getStatus(){return status;}
    public void setPatientName(String v){patientName=v;}
    public void setDoctorName(String v){doctorName=v;}
    public void setAppointmentDate(LocalDate v){appointmentDate=v;}
    public void setReason(String v){reason=v;}
    public void setStatus(String v){status=v;}
}
