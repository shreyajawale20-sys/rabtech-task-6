package com.capstone.medicare.patient;

import com.capstone.medicare.exception.ResourceNotFoundException;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/patients")
public class PatientController {
    private final PatientRepository repository;
    public PatientController(PatientRepository repository){this.repository=repository;}

    @GetMapping public List<Patient> all(){return repository.findAll();}
    @GetMapping("/{id}") public Patient get(@PathVariable Long id){
        return repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Patient not found: "+id));
    }
    @PostMapping public Patient create(@Valid @RequestBody Patient patient){return repository.save(patient);}
    @PutMapping("/{id}") public Patient update(@PathVariable Long id,@Valid @RequestBody Patient input){
        Patient p=get(id);p.setName(input.getName());p.setAge(input.getAge());p.setGender(input.getGender());p.setEmail(input.getEmail());p.setPhone(input.getPhone());return repository.save(p);
    }
    @DeleteMapping("/{id}") public void delete(@PathVariable Long id){repository.delete(get(id));}
}
