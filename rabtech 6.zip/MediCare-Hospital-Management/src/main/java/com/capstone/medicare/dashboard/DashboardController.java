package com.capstone.medicare.dashboard;

import com.capstone.medicare.appointment.AppointmentRepository;
import com.capstone.medicare.doctor.DoctorRepository;
import com.capstone.medicare.patient.PatientRepository;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {
    private final PatientRepository patients;
    private final DoctorRepository doctors;
    private final AppointmentRepository appointments;
    public DashboardController(PatientRepository p,DoctorRepository d,AppointmentRepository a){patients=p;doctors=d;appointments=a;}

    @GetMapping("/summary")
    public Map<String, Long> summary(){
        return Map.of("patients",patients.count(),"doctors",doctors.count(),"appointments",appointments.count());
    }
}
