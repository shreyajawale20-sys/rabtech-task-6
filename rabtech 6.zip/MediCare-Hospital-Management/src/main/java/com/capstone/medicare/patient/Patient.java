package com.capstone.medicare.patient;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
public class Patient {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotBlank private String name;
    @Min(0) @Max(120) private int age;
    @NotBlank private String gender;
    @NotBlank @Email private String email;
    private String phone;

    public Patient(){}
    public Long getId(){return id;}
    public String getName(){return name;}
    public int getAge(){return age;}
    public String getGender(){return gender;}
    public String getEmail(){return email;}
    public String getPhone(){return phone;}
    public void setName(String v){name=v;}
    public void setAge(int v){age=v;}
    public void setGender(String v){gender=v;}
    public void setEmail(String v){email=v;}
    public void setPhone(String v){phone=v;}
}
