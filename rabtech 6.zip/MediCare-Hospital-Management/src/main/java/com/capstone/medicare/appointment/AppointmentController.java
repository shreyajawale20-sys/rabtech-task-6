package com.capstone.medicare.appointment;

import com.capstone.medicare.exception.ResourceNotFoundException;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/appointments")
public class AppointmentController {
    private final AppointmentRepository repository;
    public AppointmentController(AppointmentRepository repository){this.repository=repository;}

    @GetMapping public List<Appointment> all(){return repository.findAll();}
    @GetMapping("/{id}") public Appointment get(@PathVariable Long id){
        return repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Appointment not found: "+id));
    }
    @PostMapping public Appointment create(@Valid @RequestBody Appointment appointment){
        appointment.setStatus("BOOKED"); return repository.save(appointment);
    }
    @PatchMapping("/{id}/status") public Appointment updateStatus(@PathVariable Long id,@RequestParam String status){
        if(!List.of("BOOKED","COMPLETED","CANCELLED").contains(status.toUpperCase())) throw new IllegalArgumentException("Status must be BOOKED, COMPLETED, or CANCELLED");
        Appointment a=get(id);a.setStatus(status.toUpperCase());return repository.save(a);
    }
    @DeleteMapping("/{id}") public void delete(@PathVariable Long id){repository.delete(get(id));}
}
