package com.capstone.medicare.doctor;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
public class Doctor {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotBlank private String name;
    @NotBlank private String specialization;
    @NotBlank @Email private String email;
    private String availability = "Available";

    public Doctor() {}
    public Doctor(String name, String specialization, String email) {
        this.name=name; this.specialization=specialization; this.email=email;
    }
    public Long getId(){return id;}
    public String getName(){return name;}
    public String getSpecialization(){return specialization;}
    public String getEmail(){return email;}
    public String getAvailability(){return availability;}
    public void setName(String v){name=v;}
    public void setSpecialization(String v){specialization=v;}
    public void setEmail(String v){email=v;}
    public void setAvailability(String v){availability=v;}
}
