package com.capstone.medicare.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {
    @Bean
    OpenAPI hospitalOpenAPI() {
        return new OpenAPI().info(new Info()
            .title("MediCare Hospital Management API")
            .version("1.0.0")
            .description("REST APIs for doctors, patients, and appointment management."));
    }
}
