# MediCare Hospital Management Portal

A full-stack Java capstone demonstration: Spring Boot REST backend, responsive HTML/CSS/JavaScript frontend, H2 database, validation, centralized exception handling, and Swagger UI.

## Features
- Dashboard with live patient, doctor, and appointment counts
- Patient create/list workflows
- Doctor create/list workflows
- Appointment booking, listing, and cancellation
- Responsive desktop and mobile layout
- Spring Data JPA and H2 local database
- Global JSON exception responses using `@RestControllerAdvice` / `@ExceptionHandler`
- Springdoc OpenAPI documentation
- Basic HTTP authentication and BCrypt encoder bean

## Requirements
- JDK 17+
- Maven 3.8+
- Browser

## Run
From the project root:

```bash
mvn spring-boot:run
```

Open:
- Frontend: http://localhost:8080/
- Swagger UI: http://localhost:8080/swagger-ui.html
- OpenAPI JSON: http://localhost:8080/v3/api-docs
- H2 console: http://localhost:8080/h2-console

H2 console JDBC URL: `jdbc:h2:file:./data/medicare`, username `sa`, blank password.

## API endpoints

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/dashboard/summary` | Dashboard totals |
| GET | `/api/patients` | List patients |
| POST | `/api/patients` | Create patient |
| GET | `/api/patients/{id}` | Find patient |
| PUT | `/api/patients/{id}` | Update patient |
| DELETE | `/api/patients/{id}` | Delete patient |
| GET | `/api/doctors` | List doctors |
| POST | `/api/doctors` | Create doctor |
| GET | `/api/doctors/{id}` | Find doctor |
| PUT | `/api/doctors/{id}` | Update doctor |
| DELETE | `/api/doctors/{id}` | Delete doctor |
| GET | `/api/appointments` | List appointments |
| POST | `/api/appointments` | Book appointment |
| PATCH | `/api/appointments/{id}/status?status=CANCELLED` | Change status |
| DELETE | `/api/appointments/{id}` | Delete appointment |

## Example request bodies

Patient:
```json
{"name":"Aarav Sharma","age":28,"gender":"Male","email":"aarav@example.com","phone":"9000000000"}
```

Doctor:
```json
{"name":"Dr. Meera Shah","specialization":"Cardiology","email":"meera@example.com"}
```

Appointment:
```json
{"patientName":"Aarav Sharma","doctorName":"Dr. Meera Shah","appointmentDate":"2026-11-05","reason":"Routine consultation"}
```

## Architecture
Browser frontend (`src/main/resources/static`) → REST controllers → Spring Data JPA repositories → H2 database. Controllers use Bean Validation; `GlobalExceptionHandler` maps common failures to JSON HTTP responses. Springdoc scans REST endpoints and generates OpenAPI documentation.

## Important security / scope note
This is an educational starter, not a production hospital system. The included security setup uses HTTP Basic for protected APIs; it does not yet implement JWT login, persistent user registration, or fully enforced Doctor/Patient roles. To satisfy a strict authenticated-session or JWT capstone rubric, implement and test that authentication flow before submission. Patient information here is demo data only; do not enter real medical records. For production, add proper identity management, authorization per resource, audit trails, HTTPS, backups, and secrets management.
